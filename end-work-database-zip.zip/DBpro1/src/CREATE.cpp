#include<iostream>
#include<algorithm>
#include<string>
#include<cstring>
#include<vector>
#include<stack>
#include<queue>
#include<map>
#include<cstdio>
#include<cmath>
#define debug_mode false
#define mem(s,value) memset(s,value,sizeof(s))
#define IOS ios::sync_with_stdio(false)
#define INTXT frein("in.txt");
#define frein(s)  freopen(s,"r",stdin)
#define DEBUG if(debug_mode)
#define esp 1e-8
//#pragma comment(linker, "/STACK:1024000000,1024000000")
typedef long long ll;
typedef unsigned long long ull;
using namespace std;
const double PI = acos(-1.0);
const int maxn = 1e5 + 10;


signed main(){
    frein("in.txt");
    
}



