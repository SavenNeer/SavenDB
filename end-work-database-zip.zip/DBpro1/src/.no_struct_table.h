



// #ifndef _STRUCT_TABLE_H_
// #define _STRUCT_TABLE_H_

// #include"MetaType.h"
// #include<vector>

// /* 单列信息 */
// class ColInfo{
// public:
//     /* 列级基本属性 */
//     int id_index;//列编号
//     std::string col_name;//属性名
//     Meta::Type data_type;//属性类型
//     int data_limit;//数据限制

//     /* 列级约束特性 */
//     bool isprikey;//主码标识
//     std::vector<string> abri;//约束

//     /* 外码参照 */
//     bool isfgnkey;//是否是外码
//     std::string ref_table;//参照表
//     std::string ref_colname;//参照列
// public:
//     ColInfo(){};
//     ~ColInfo(){};
// };


// /* 表信息 */
// class TableInfo{
// public:
//     //表名
//     std::string table_name;
//     //列信息汇总
//     std::vector<ColInfo> cols;
//     //参照关系汇总
//     std::vector< std::pair<std::string,std::string> > ref;
//     //完全主键
//     std::vector< std::string > prikeys;
// public:
//     TableInfo(){};
//     ~TableInfo(){};
// };


// /* SQL解析 */
// int paser_CREATE_TABLE(const std::string order,TableInfo& output){
//     //
// }

// /* 单个表信息读取函数 */


// /* 单个表信息输出 */





// #endif



