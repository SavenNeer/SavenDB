// // MetaType.cpp

// #include <cmath>
// #include <algorithm>
// #include <malloc.h>
// #include <cstring>
// #include "TypeStat.h"
// #include "MetaType.h"


// #ifndef _METATYPE_CPP_
// #define _METATYPE_CPP_


// // class MetaType

// //默认初始化
// Meta::MetaType::MetaType(){
//     this->_type = Meta::Type::TYPE_UNKNOW;
//     this->_isNULL = true;
//     this->data = nullptr;
// }

// Meta::MetaType::MetaType(Type _type=Type::TYPE_UNKNOW,ubeta8 size=0){
//     this->_type = _type;
//     this->_isNULL = true;
//     this->data = nullptr;
//     switch (this->_type){
//         case Type::TYPE_INT:
//             data = (char*)malloc(sizeof(int));
//             break;
//         case Type::TYPE_VARCHAR:
//             data = (char*)malloc(sizeof(char)*3);//maxlen curlen backend
//             data[0] = size;//maxlen = size = (int)data[0]
//             data[1] = data[2] = 0;//curlen = 0 = (int)data[1]
//             break;
//         case Type::TYPE_CHAR:
//             //data[0]尺寸 && data[1~size+1]数据
//             data = (char*)malloc(sizeof(char)*(size+2));
//             for(int i=1;i<=size;i++) data[i] = ' ';
//             data[size+1] = 0;
//             data[0] = size;
//             break;
//         case Type::TYPE_DOUBLE:
//             data = (char*)malloc(sizeof(double));
//             break;
//         case Type::TYPE_LONG:
//             data = (char*)malloc(sizeof(long));
//             break;
//         default:
//             break;
//     }
// }

// Meta::MetaType::~MetaType(){
//     if(data){
//         free(data);
//         data = nullptr;
//     }
// }

// //拷贝构造
// Meta::MetaType::MetaType(const MetaType& rhs){
//     this->_type = rhs._type;
//     this->_isNULL = rhs._isNULL;
//     this->data = nullptr;
//     switch (rhs._type){
//         case Type::TYPE_INT:
//             this->data = (char*)malloc(sizeof(int));
//             *this->data = *rhs.data;
//             break;
//         case Type::TYPE_VARCHAR:
//             ubeta8 maxSize = rhs.data[0];
//             ubeta8 curSize = rhs.data[1];
//             this->data = (char*)malloc(sizeof(char)*(3+curSize));
//             this->data[0] = maxSize;
//             this->data[1] = curSize;
//             memcpy(&this->data[2],&rhs.data[2],curSize*sizeof(char));
//             this->data[2+curSize] = 0;
//             break;
//         case Type::TYPE_CHAR:
//             ubeta8 CharSize = this->data[0];
//             this->data = (char*)malloc(sizeof(char)*(CharSize+2));
//             this->data[0] = rhs.data[0];
//             memcpy(&this->data[1],&rhs.data[1],CharSize*sizeof(char));
//             this->data[CharSize+1] = 0;
//             break;
//         case Type::TYPE_DOUBLE:
//             this->data = (char*)malloc(sizeof(double));
//             *this->data = *rhs.data;
//             break;
//         case Type::TYPE_LONG:
//             this->data = (char*)malloc(sizeof(long));
//             *this->data = *rhs.data;
//             break;
//         default:
//             break;
//     }
// }

// bool Meta::MetaType::isNull(){
//     return this->_isNULL;
// }

// bool Meta::MetaType::isVaildType(){
//     return this->_type != Type::TYPE_UNKNOW;
// }

// Meta::Type Meta::MetaType::dataType(){
//     return this->_type;
// }

// void Meta::MetaType::setNull(){
//     this->_isNULL = true;
//     //
// }

// bool Meta::MetaType::operator== (const MetaType& rhs){
//     //相等判定
//     // 所有空值都相同 
//     // 不同类型的变量一定不同
//     // 同类型变量且同值才相同
//     if(this->_isNULL == rhs._isNULL) { return true; }
//     if(this->_type != rhs._type) { return false; }
//     if( (this->_isNULL && !rhs._isNULL) || (!this->_isNULL && rhs._isNULL) ) { return false; }
//     switch(this->_type){
//         case Type::TYPE_DOUBLE:
//             return memcmp(this->data,rhs.data,sizeof(double)) == 0;
//         case Type::TYPE_INT:
//             return memcmp(this->data,rhs.data,sizeof(int)) == 0;
//         case Type::TYPE_LONG:
//             return memcmp(this->data,rhs.data,sizeof(long)) == 0;
//         case Type::TYPE_CHAR:
//             ubeta8 len = this->data[0];
//             if(len != rhs.data[0]) return false;
//             return memcmp(&this->data[1],&rhs.data[1],sizeof(char)*len) == 0;
//         case Type::TYPE_VARCHAR:
//             ubeta8 len = this->data[1];
//             if(len != rhs.data[1]) return false;
//             return memcmp(&this->data[2],&rhs.data[2],sizeof(char)*len) == 0;
//     }
//     return false;
// }



// // class MetaController

// const ubeta8 Meta::MetaController::sizeofCHAR = sizeof(char);
// const ubeta8 Meta::MetaController::sizeofINT = sizeof(int);
// const ubeta8 Meta::MetaController::sizeofDOUBLE = sizeof(double);
// const ubeta8 Meta::MetaController::sizeofCHAR = sizeof(char);
// const ubeta8 Meta::MetaController::sizeofLONG = sizeof(long);
// const ubeta8 Meta::MetaController::sizeofUNKNOW = 0;


// int Meta::MetaController::setValue_Int(MetaType& rhs,int value){
//     if(rhs._type == Type::TYPE_INT){
//         memcpy(rhs.data,&value,sizeofINT);
//         rhs._isNULL = false;
//         return 0;
//     }
//     return -1;
// }

// int Meta::MetaController::setValue_DOUBLE(MetaType& rhs,double value){
//     if(rhs._type == Type::TYPE_DOUBLE){
//         memcpy(rhs.data,&value,sizeofDOUBLE);
//         rhs._isNULL = false;
//         return 0;
//     }
//     return -1;
// }

// int Meta::MetaController::setValue_LONG(MetaType& rhs,long value){
//     if(rhs._type == Type::TYPE_LONG){
//         memcpy(rhs.data,&value,sizeofLONG);
//         rhs._isNULL = false;
//         return 0;
//     }
//     return -1;
// }

// int Meta::MetaController::setValue_CHAR(MetaType& rhs,const char* strs,ubeta8 len){
//     if(rhs._type == Type::TYPE_CHAR){
//         ubeta8 maxlen = (ubeta8)rhs.data[0];
//         //限定字符串长度
//         ubeta8 curlen = std::min(len,maxlen);
//         memcpy(rhs.data,strs,curlen*sizeofCHAR);
//         //补充空格
//         while(curlen < maxlen) { rhs.data[curlen++] = ' '; }
//         rhs._isNULL = false;
//         return 0;
//     }
//     return -1;
// }

// int Meta::MetaController::setValue_CHAR(MetaType& rhs,std::string strs){
//     return this->setValue_CHAR(rhs,strs.c_str(),(ubeta8)strs.size());
// }

// int Meta::MetaController::setValue_VARCHAR(MetaType& rhs,const char* strs,ubeta8 len){
//     if(rhs._type == Type::TYPE_CHAR){
//         //逻辑上允许的最大容量
//         ubeta8 maxlen = rhs.data[0];
//         //真实容量
//         char realen = rhs.data[1];
//         //准许容量
//         ubeta8 perlen = std::min(maxlen,len);
//         //内存分配管理
//         if(rhs.data) { free(rhs.data); }
//         rhs.data = (char*)malloc(sizeofCHAR*(3+perlen));
//         rhs.data[0] = maxlen;
//         rhs.data[1] = perlen;
//         memcpy(&rhs.data[2],strs,perlen*sizeofCHAR);
//         rhs.data[2+perlen] = 0;
//         rhs._isNULL = false;
//         return 0;
//     }
//     return -1;
// }

// int Meta::MetaController::setValue_VARCHAR(MetaType& rhs,std::string strs){
//     return this->setValue_VARCHAR(rhs,strs.c_str(),(ubeta8)strs.size());
// }

// Meta::MetaType Meta::MetaController::getSum(MetaType& rhs1,MetaType& rhs2){
//     //字符串连接 数字相加 null+any=any null+null=null invaild=null
//     // if(rhs1._isNULL && rhs2._isNULL) return Meta::  __MetaType_NULL__;
//     // if(rhs1._type == rhs2._type){
//     //     if(rhs1._isNULL && rhs2._isNull)
//     // }
//     // return __MetaType_NULL__;
// }

// #endif

