
#include <iostream>
#include <iomanip>
#include <boost/regex.hpp>
using namespace std;
int main(int argc, const char* argv[]) 
{
    string aim = "(?<=select).+?(?=from)";
	boost::regex patn(aim, boost::regex::icase);
	//mark_count 返回regex中带标记子表达式的数量。带标记子表达式是指正则表达式中用圆括号括起来的部分
	cout << "subexpressions: " << patn.mark_count() << endl;
 
	string line = "select count(col2) from table_name where col1;";
    boost::match_results<string::const_iterator> results;
    if (boost::regex_search(line, results, patn, boost::match_default))
    {
        const int n = results.size();
        for (int i = 0; i < n; i++)
        {
            cout << results[i] << endl;
        }
    }
    else
    {
        cout << "<false>" << endl;
    }
    return 0;
}


 
// #include <iostream>
// #include <iomanip>
// #include <boost/regex.hpp>
// using namespace std;
// int main(int argc, const char* argv[]) 
// {
// 	if (argc != 2) 
// 	{
// 		cerr << "Usage: " << argv[0] << " regex-str" << endl;
// 		return 1;
// 	}
 
// 	boost::regex e(argv[1], boost::regex::icase);
// 	//mark_count 返回regex中带标记子表达式的数量。带标记子表达式是指正则表达式中用圆括号括起来的部分
// 	cout << "subexpressions: " << e.mark_count() << endl;
 
// 	string line;
// 	while (getline(cin, line)) 
// 	{
// 		boost::match_results<string::const_iterator> m;
// 		if (boost::regex_search(line, m, e, boost::match_default)) 
// 		{
// 			const int n = m.size();
// 			for (int i = 0; i < n; ++i)
// 			{
// 				cout << m[i] << " ";
// 			}
// 			cout << endl;
// 		} 
// 		else 
// 		{
// 			cout << setw(line.size()) << setfill('-') << '-' << right << endl;
// 		}
// 	}
//     return 0;
// }

