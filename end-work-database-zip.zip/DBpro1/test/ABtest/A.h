// #include<iostream>
// #ifndef _A_H_
// #define _A_H_

// #ifdef _B_H_
// std::cout << "in A, B has been defind" << std::endl;
// #else
// //一个可能的B前向声明
// namespace nameB{
//     class B;
// }
// #endif

// namespace nameA{
//     class A{
//     public:
//         int xa = 1;
//         A();
//         ~A();
//         int test(nameB::B* rhs);
//     };
// };

// #endif
