// #ifndef _B_CPP_
// #define _B_CPP_

// #include"B.h"
// #include<iostream>
// #include<stdio.h>
// using namespace nameA;

// nameB::B::B(){
//     printf("B is start\n");
// }


// nameB::B::~B(){
//     printf("B is delete\n");
// }

// int nameB::B::test(nameA::A* rhs){
//     printf("B test() is run [%d]\n",rhs->xa);
//     return 0;
// }

// #endif
