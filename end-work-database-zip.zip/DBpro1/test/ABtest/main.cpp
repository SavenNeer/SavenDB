

// #include<iostream>
// #include<stdio.h>
// #include"A.h"
// #include"B.h"


// using namespace std;

// signed main(){
//     nameA::A a;
//     nameB::B b;
//     a.test(&b);
//     b.test(&a);
//     return 0;
// }
