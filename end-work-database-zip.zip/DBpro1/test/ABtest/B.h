// #include<iostream>
// #ifndef _B_H_
// #define _B_H_

// #ifdef _A_H_
// std::cout << "in B, A has been defind" << std::endl;
// #else
// //一个可能的A前向声明
// namespace nameA{
//     class A;
// }
// #endif

// namespace nameB{
//     class B{
//     public:
//         int xb = 2;
//         B();
//         ~B();
//         int test(nameA::A* rhs);
//     };
// };

// #endif
