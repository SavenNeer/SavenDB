// #ifndef _A_CPP_
// #define _A_CPP_

// #include"A.h"
// #include<iostream>
// #include<stdio.h>
// using namespace nameB;

// nameA::A::A(){
//     printf("A is start\n");
// }


// nameA::A::~A(){
//     printf("A is delete\n");
// }

// int nameA::A::test(nameB::B* rhs){
//     printf("A test() is run [%d]\n",rhs->xb);
//     return 0;
// }

// #endif

