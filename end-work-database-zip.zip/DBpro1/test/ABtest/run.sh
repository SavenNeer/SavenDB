g++ B.cpp A.cpp main.cpp -o test
