
#include<iostream>
#include<cstdio>
#include<fstream>
#include<cstring>
#include<ostream>
#include<string>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<assert.h>
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<errno.h>
#include<string.h>
#include<sys/sendfile.h>
#include<sys/uio.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>
#include<pthread.h>
#include<sys/time.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<sys/epoll.h>
#include<sys/wait.h>
#include<sys/mman.h>
#include"../include/utils.h"
#include<signal.h>


using namespace std;

int main(){
    string line = "tbna LONG NOT NULL UNIQUE PRIMARY KEY";
    vector<string> res = SavenUtils::RegexSearch(line,"(unique|not null|primary key)");
    cout << res.size() << endl;
    for(string rhs : res){
        cout << rhs << endl;
    }
    return 0;
}

// std::vector<std::string> check()
// {
//     std::string str = "tbna LONG NOT NULL UNIQUE PRIMARY KEY";
 
//     boost::regex expression("(unique|not null|primary key)",boost::regex::icase);
//     boost::smatch what;
//     std::vector<std::string> res;
 
// 	std::string::const_iterator start = str.begin();
// 	std::string::const_iterator end = str.end();
//     while(boost::regex_search(start, end, what, expression)){
// 		std::cout << what[0] << std::endl;
//         res.push_back(SavenUtils::trim(what[0]));
// 		start = what[0].second;
//     }
// 	return res;
// }



/*
// 文件按页面开辟与回收操作验证

void new_back(MManage::FileController& fct){
    fct.__alloc_Back();
    cout << fct.pagenum << "," << fct.__realsize << endl;
    system("hexdump -c /home/ubuntu/DBpro1/test/test.tb");
    printf("\n\n");
}

void del_back(MManage::FileController& fct){
    fct.__delet_Back();
    cout << fct.pagenum << "," << fct.__realsize << endl;
    system("hexdump -c /home/ubuntu/DBpro1/test/test.tb");
    printf("\n\n");
}

signed main(){
    //新建文件
    int fd = open("test.tb",O_RDWR|O_CREAT,0666);
    ftruncate(fd,MManage::PageSize_Numofubeta8);
    close(fd);
    //建立页面管理程序
    MManage::FileController fct("test.tb");
    cout << "init-pagenum = " << fct.pagenum << endl;
    fct.__init_PageSpace(0);
    //
    new_back(fct);
    new_back(fct);
    new_back(fct);
    del_back(fct);
    new_back(fct);
    del_back(fct);
    //
    fct.__close();
    return 0;
}
*/


