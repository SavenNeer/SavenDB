#include"../include/utils.h"

#include<iostream>
#include<cstdio>
#include<fstream>
#include<cstring>
#include<ostream>
#include<string>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<assert.h>
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<errno.h>
#include<string.h>
#include<sys/sendfile.h>
#include<sys/uio.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>
#include<pthread.h>
#include<sys/time.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<sys/epoll.h>
#include<sys/wait.h>
#include<sys/mman.h>
#include<signal.h>



using namespace std;

// 测试正则表达式的匹配与查询功能

signed main(){
    cout << SavenUtils::RegexMatch("colname char(32) UNIQUE","\\b(long|char|int|double|varchar)\\s*\\(\\s*[0-9]+\\s*\\)") << endl;
    vector<string> res = SavenUtils::RegexSearch("colname char(32) UNIQUE","\\b(long|char|int|double|varchar)\\s*\\(\\s*[0-9]+\\s*\\)");
    for(string& rhs : res){
        cout << rhs << endl;
    }
    // string line = "create table tbname3 (tbname3 LONG NOT NULL UNIQUE PRIMARY KEY,colname char(32) UNIQUE,age int PRIMARY KEY);";
    // // cout << SavenUtils::RegexMatch(line,"^(create table) .+ \\((.+,)+.+\\);?") << endl;
    // // vector<string> res = SavenUtils::RegexSearch(line,"(?<=create table ).+(?= \\()");
    // // for(auto& rhs : res){
    // //     cout << rhs << endl;
    // // }
    // // // string line = ""
    return 0;
}


