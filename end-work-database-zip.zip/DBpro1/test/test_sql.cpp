#include<string>
#include<iostream>
#include"../SQLparser.module/sql_create.h"
using namespace std;


int main(){
    freopen("in.txt","r",stdin);
    string line = "";
    int cnt = 0;
    while(1){
        char ch = getchar();
        if(ch == '\n'){
            ch = ' ';
        }else if(ch == ';'){
            break;
        }
        line += ch;
        cnt++;
        if(cnt >= 250){
            break;
        }
    }
    cout << "cnt = " << cnt << endl;
    DBInfo::TableInfo info;
    int res = SQL_Create::create_table(line,info);
    info.show();
    return 0;
}


