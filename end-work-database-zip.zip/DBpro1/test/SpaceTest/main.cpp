#include "SpaceB.h"
#include "SpaceA.h"

int main(int argc, char *argv[]){
    TestB::SpaceB b;
    TestA::SpaceA a;
    //
    // b.a = &a;
    // a.b = &b;
    //
    a.printA();
    b.printB();
}

