#pragma once

//声明
namespace TestB{
    class SpaceB;
}

namespace TestA {
	class SpaceA {
	public:
		SpaceA();
		~SpaceA();
        void checkA();
		void printA();
        TestB::SpaceB* b;
	};
}

