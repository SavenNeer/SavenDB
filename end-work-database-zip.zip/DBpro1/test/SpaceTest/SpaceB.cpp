#include<iostream>
#include "SpaceB.h"
#include "SpaceA.h"
// using namespace TestB;
// using namespace TestA;

TestB::SpaceB::SpaceB() {
    this->a = nullptr;
}

TestB::SpaceB::~SpaceB() {
}

void TestB::SpaceB::checkB(){
    std::cout << "this is checkB()" << std::endl;
}

void TestB::SpaceB::printB() {
    std::cout << "SpaceB print()" << std::endl;
	std::cout << "use A: ";
    a->checkA();
}
