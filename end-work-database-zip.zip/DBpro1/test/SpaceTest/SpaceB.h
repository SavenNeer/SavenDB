#pragma once

//声明
namespace TestA {
	class SpaceA;
}

namespace TestB {
	class SpaceB {
	public:
		SpaceB();
		~SpaceB();
		void printB();
        void checkB();
		TestA::SpaceA* a;//使用的时候，必须加上命名空间
	};
}

