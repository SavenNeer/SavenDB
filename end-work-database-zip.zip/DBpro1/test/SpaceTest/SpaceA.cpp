#include<iostream>
#include "SpaceA.h"
#include "SpaceB.h"
// using namespace TestA;
// using namespace TestB;

TestA::SpaceA::SpaceA() {
    this->b = nullptr;
}

TestA::SpaceA::~SpaceA() {
}

void TestA::SpaceA::checkA(){
    std::cout << "this is checkA()" << std::endl;
}

void TestA::SpaceA::printA() {
    std::cout << "SpaceA print()" << std::endl;
	std::cout << "use B: ";
    b->checkB();
}

