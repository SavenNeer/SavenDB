g++ SpaceA.cpp SpaceB.cpp main.cpp -o test
