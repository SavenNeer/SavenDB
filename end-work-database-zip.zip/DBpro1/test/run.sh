g++ ../SQLparser.module/sql_create.cpp test_sql.cpp ../include/utils.cpp ../MetaST.module/MetaType.cpp -o test -lboost_regex
# g++ test_sql.cpp ../SQLparser.module/sql_create.cpp -o test -lboost_regex
# g++ test2.cpp -o test -lboost_regex && ./test

