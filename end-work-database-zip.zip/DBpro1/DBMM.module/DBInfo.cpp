// DBInfo.cpp


#ifndef _DBINFO_CPP_
#define _DBINFO_CPP_

#include"DBInfo.h"


/* 前向声明对应的头文件引用 */

#include"../TableMM.module/table.h"


/* 实现主体部分 */

void DBInfo::Attribute::show(){
    std::string ty = Meta::showType(data_type);
    // std::string ty = "123";
    printf("%s %s(%d) pri/ref:%d/%d NOT_NULL/UNIQUE:%d/%d ref(%s.%s)\n"
    ,col_name.c_str()
    ,ty.c_str()
    ,data_type_limit
    ,pri_key,ref_key
    ,data_not_null,data_unique
    ,ref_key == true ? ref_tbname.c_str() : "null"
    ,ref_key == true ? ref_col_name.c_str() : "null");
}

void DBInfo::TableInfo::show(){
    printf("[ --> table name:%s <-- ]\n",tbname.c_str());
    int lenth = AttrList.size();
    printf("AttrList size = %d\n",lenth);
    for(int i=0;i<lenth;i++){
        printf("%2d] ",i);
        AttrList[i].show();
    }
    //主码信息
    printf("PriKeys(");
    int flag = 0;
    for(int i=0;i<PriKeys.size();i++){
        if(flag++)printf(",");
        printf("%s",PriKeys[i].c_str());
    }
    printf(");\n");
    printf("ForeignKeys Please See in Attributes\n");
}



#endif // _DBINFO_CPP_


