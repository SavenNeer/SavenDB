// dbInfo.h


#ifndef _DBINFO_H_
#define _DBINFO_H_


#include"../MetaST.module/MetaType.h"
#include<string>
#include<vector>
#include<map>

/* 前向声明区域 */

namespace TableMM{
    class Table;
}



/* 表类声明 */

namespace DBInfo{

    /* 表信息的管理框架 */

    //单条表属性描述
    class Attribute{
    public:
        //是否为主码
        bool pri_key = false;
        //是否为外码
        bool ref_key = false;
        //列名
        std::string col_name;
        //数据类型
        Meta::Type data_type;
        //数据限制
        int data_type_limit = 0;

        //非空属性
        bool data_not_null = false;
        //唯一属性
        bool data_unique = false;
        
        //参照表名
        std::string ref_tbname;
        //参照表列
        std::string ref_col_name;
    public:
        Attribute();
        void show();
    };

    //单表信息存储类
    class TableInfo{
    public:
        //表名
        std::string tbname;
        //单列属性信息
        std::vector<Attribute> AttrList;
        //表内参照关系集合
        //vector:self_col_name,pair<other_table,other_col_name>
        // ReferenceList RefList;
        //完全主码-用于实际的表信息处理中参照的主码
        std::vector<std::string> PriKeys;
    public:
        TableInfo();

        void show();
    };

    /* 全局表字典
    用于管理存储表信息 加载不同的表数据
    接收单个表提出的[全局外码参照验证]
    维护数据库全局的表属性参照关系和依赖关系

    全局表字典在SavenDB内核初始化时即加载全体表信息
    但不加载表内容的所有<p-g>索引信息
    只有内核请求建立表实体时 才允许获取<p-g>内存索引
    */
    class DBTables{
    public:
        //存储表信息 根据标明获取表属性对象
        std::map<std::string,TableInfo> inner_tables;
        //内部表个数
        int table_num = 0;
    public://表的实体管理
        //当前活跃的表实体总数
        int alive_tables = 0;
        //活跃表实体集合
        std::map<std::string,TableMM::Table> allTables;
    public:
        DBTables(){};
    };


    /* 视图信息管理框架 */

};



#endif // _DBINFO_H_


