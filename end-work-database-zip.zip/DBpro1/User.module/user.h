// user.cpp

#ifndef _USER_H_
#define _USER_H_

#include<string>
#include"../MetaST.module/MetaType.h"


namespace UserMM{

    //操作类型
    enum Oper{
        ALL=0,
        SELECT,
        UPDATE,
        INSERT,
        DELETE,
        CREATE,
        ALTER,
        DROP
    };

    class Authority{
    public:
        //授权者
        std::string giver;
        //被授权者
        std::string mbody;
        //表名
        std::string tablename;
        //列名
        std::string colname;
        //允许的操作
        Oper operations;
        //能够转授权
        bool can_grant = false;
    public:
        Authority();
    };

    class UserInfo{
    public:
        //用户名
        std::string username;
        //密码
        std::string password;

    }

};



#endif //_USER_H_

