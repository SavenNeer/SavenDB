// table.cpp

#ifndef _TABLE_CPP_
#define _TABLE_CPP_


/* 前向声明对应的头文件引用 */

#include"DBInfo.h"
#include"table.h"


/* 实现主体部分 */

TableMM::Table::Table(){
    this->table_name = "";
    this->isVirtual = false;
    this->tbinfo = nullptr;
    this->tb_tuples.clear();
    this->isVaild = false;
}

//带参初始化
TableMM::Table::Table(const std::string table_name,bool isVirtual=false,DBInfo::TableInfo* tbinfo=nullptr){
    if(isVirtual == true && tbinfo != nullptr){
        this->isVaild = true;
        return;
    }
    if(isVirtual = false && tbinfo == nullptr){
        this->isVaild = true;
        return;
    }
    //初始化回头再写
}

//获取元组总个数-表的逻辑大小
int TableMM::Table::length()const{
    return this->tb_tuples.size();
}



#endif // _TABLE_CPP_

