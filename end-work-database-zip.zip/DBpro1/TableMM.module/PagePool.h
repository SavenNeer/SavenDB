// PagePool.h


#ifndef _PAGEPOOL_H_
#define _PAGEPOOL_H_


#include"../PagerMM.module/PageManager.h"
#include<stdio.h>
#include<vector>
#include<map>

/*
内存池
提供页面管理的中间程序
能够管理虚拟页面以及实体页面的生成
向上为基础表和虚拟表提供存储服务

PagePool - File - tables
*/

namespace PagesMM{

    class PagePool{
    private:
        //底层文件管理
        MManage::FileController* fc = nullptr;
        //最大实体/虚拟页面容量
        int max_pages = 20;
        //页面池指针
        std::vector<MManage::PageInfo*> pool;
        //固定页面指针
        std::map<MManage::PageInfo*,int> keep;

        //可在此处定义页面替换策略以加快页面池效率

    public:
        //构造函数
        PagePool(MManage::FileController* fc = nullptr);

        //获取当前页面池大小
        //@return int(容量大小-页面个数)
        int __PageNum_inPool();

        //修改页面池容量
        //@params 容量大小int >= 1
        //@return int(state)当前容量大小
        int modifyPoolSize(int pool_size);

    public:
        //新页面装填
        //@return int(state) 页面索引码ubeta8
        int __load_newPage(ubeta8& pageIndex);

        //指定页面装填
        //@params 页面索引码ubeta8
        //@return int(state)
        int __load_Page(ubeta8 pageIndex);

        //页面是否位于页面池
        //@params 页面索引码ubeta8
        //@return int(state)
        int __PageinPool(ubeta8 pageIndex);

        //页面推出
        //@params 页面索引码ubeta8
        //@return int(state)
        int __push_Page(ubeta8 pageIndex);

        //页面数据强制同步
        //@params 页面索引码ubeta8
        //@return int(state)
        int __sync_Page(ubeta8 pageIndex);

        //页面固定
        //@params 页面索引码ubeta8
        //@return int(state)
        int __lock_Page(ubeta8 pageIndex);

        //页面解锁
        //@params 页面索引码ubeta8
        //@return int(state)
        int __unlock_Page(ubeta8 pageIndex);

        //页面固定状态
        //@params 页面索引码ubeta8
        //@return int(state)
        int __page_islock(ubeta8 pageIndex);

    public:
        //数据存储
        //@params ubeta8[]数据缓冲 int数据长度 ubeta8
        //@return int(state) <p-g>索引
        int WriteIn(ubeta8* data,int wtsize,ubeta8 pageIndex,ubeta8 groupIndex);

        //数据读出准备
        //@params <p-g>索引
        //@return int(数据大小) 出错-1
        int Read_Ready(ubeta8 pageIndex,ubeta8 groupIndex);

        //数据读出 - 使用前调用read_ready()准备数据并获取长度
        //@params ubeta8[]缓冲区指针
        //@return int(state)
        int Read_Data(ubeta8* data);

        //数据读出结束
        void Read_Over();

        //数据无效化-删除数据链的数据
        //@params <p-g>索引
        //@return int(state)
        int delete_data(ubeta8 pageIndex,ubeta8 groupIndex);

    };

};



#endif //_PAGEPOOL_H_



