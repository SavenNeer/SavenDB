g++ main2.cpp -o main2 -lboost_regex && ./main2
