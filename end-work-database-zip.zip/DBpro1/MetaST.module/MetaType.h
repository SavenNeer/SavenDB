// MetaType.h

#ifndef _METATYPE_H_
#define _METATYPE_H_

#include<string>
#include"../include/TypeStat.h"


namespace Meta{

    /* -----元数据类型----- */

    //支持的数据类型
    enum Type{
        TYPE_INT,//
        TYPE_DOUBLE,
        TYPE_LONG,
        TYPE_CHAR,//必须有限制长度
        TYPE_VARCHAR,//必须有限制长度
        TYPE_UNKNOW
    };

    //解析数据类型
    std::string showType(Meta::Type ty);

    /* MetaType
     * MetaType类是拥有特殊的内存申请权限的类型
     * 对于没有实体表内存页面依托的元数据而言
     * MetaType允许个体直接向操作系统申请必要的空间
     * 但是 申请前必须明确数据类型 并根据数据类型及其限制申请固定大小的空间
     * 有效内存的声明周期必须由每一个MetaType对象负责
     * 
     * 这里必须强调:MetaType内部指针指向的内存页面必须是存在于页面池中的
     * 如果不能保证 可以要求页面池固定所指向的页面 但并不推荐这样做
     * 更理想的情况是 在页面上遍历时随时生成MetaType进行解析 把MetaType作为工具类使用
     * 
     * 事实上 我不建议多个实体表之间进行数据操作时使用[自开辟内存的方式]
     * SavenDB内核应当保证尽量将自开辟方法限制在初始状态下
    */
    class MetaType{
    public:
        //自开辟内存标识
        bool self_molloc = false;
        //指向内存
        ubeta8* mm_pointer = nullptr;
        //类型 可能反映出长度 但是最好参照数据字典说明的长度
        Type data_type = Type::TYPE_UNKNOW;
        //数据字典反映出的长度 需要SavenDB的内核指定
        ubeta8 data_size;
    public:
        //指定内存模式
        MetaType(ubeta8* mm_pointer,ubeta8 data_size);
        //自开辟内存模式
        MetaType(Meta::Type data_type,ubeta8 data_size);
        //析构函数注意销毁自开辟内存
        ~MetaType();
    public://下面涉及元数据的操作符实现
        //略~
    };

    /* -----元组类型----- */

    /* Tuple
     * 
     * Tuple能够向下通过PagePool直接获取内存页面的指针
     * 
     *
    */

    class Tuple{
    public:
        //
    };

};



#endif // _METATYPE_H_
