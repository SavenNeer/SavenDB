// MetaType.cpp


#ifndef _METATYPE_CPP_
#define _METATYPE_CPP_

#include"MetaType.h"


//解析数据类型
std::string Meta::showType(Meta::Type ty){
    std::string ans = "";
    switch(ty){
        case Type::TYPE_INT:
            ans = "INT";
            break;
        case Type::TYPE_DOUBLE:
            ans = "DOUBLE";
            break;
        case Type::TYPE_LONG:
            ans = "LONG";
            break;
        case Type::TYPE_CHAR:
            ans = "CAHR";
            break;
        case Type::TYPE_VARCHAR:
            ans = "VARCHAR";
            break;
        case Type::TYPE_UNKNOW:
            ans = "UNKNOW";
            break;
    }
    return ans;
}



#endif // _METATYPE_CPP_



