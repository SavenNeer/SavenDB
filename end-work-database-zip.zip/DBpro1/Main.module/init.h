//init.h
// 文件全局仅出现一次

//数据库的所有系统级全局对象的初始化区域

#ifndef _INIT_H_
#define _INIT_H_

#include"DBsys.h"




//定义数据库内核管理系统 全局唯一
#ifndef _sys_core_has_define_
#define _sys_core_has_define_

SavenDBcore DBsys;

#endif //_sys_core_has_define_






#endif //_INIT_H_

