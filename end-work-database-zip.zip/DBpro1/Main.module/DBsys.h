// DBsys.h

#ifndef _DBSYS_H_
#define _DBSYS_H_



class SavenDBcore{
public:
    //

};



#endif //_DBSYS_H_



