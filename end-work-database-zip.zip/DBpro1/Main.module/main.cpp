// main.cpp
// SavenDB
// created by SavenNeer

#include"init.h"
#include"DBsys.h"

#include <iostream>
#include <algorithm>
#include <stdio.h>
#include <string>
#include <cstring>
#include <vector>
#include <stack>
#include <set>
#include <queue>
#include <map>
#include <cstdio>
#include <list>
#include <cmath>
using namespace std;

signed main(){
    printf("SavenDB\n");
    printf("created by SavenNeer.\n");
    //初始化系统

    //用户登录界面
    string username;
    string password;
    printf("please login>");
    printf("username:");
    getline(cin,username);
    printf("password:");
    getline(cin,password);
    // //用户登录检查 登录成功后由DBsys填充用户信息
    // if(DBsys.checker.login(username,password) == false){
    //     printf("username or password error\n");
    //     DBsys.quit();
    //     return 0;
    // }
    
    //CLI模式
    string cli_order = "";
    while(1){
        cli_order = "";
        //
    }


    return 0;
}




