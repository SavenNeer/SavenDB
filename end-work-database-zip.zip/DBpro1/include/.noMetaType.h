// MetaType.h

#ifndef _METATYPE_H_
#define _METATYPE_H_


#include "TypeStat.h"
#include <string>

namespace Meta{

    enum Type{
        TYPE_INT,
        TYPE_DOUBLE,
        TYPE_LONG,
        TYPE_CHAR,
        TYPE_VARCHAR,
        TYPE_UNKNOW
    };

    class MetaController;

    class MetaType{
    private:
        friend class MetaController;
        Type _type;
        bool _isNULL;
        char* data;

    public:
        //默认初始化 UNKNOW NULL
        MetaType();
        //直接初始化
        MetaType(Type _type,usint size);
        //析构
        ~MetaType();
        //复制构造
        MetaType(const MetaType& rhs);
        //比较
        bool operator== (const MetaType& rhs);

    public:
        //是否为NULL值
        bool isNull();
        //是否是有效类型
        bool isVaildType();
        //获取数据类型
        Type dataType();
        //设置为NULL
        void setNull();
    };

    //未知类型的空元素
    #define __MetaType_NULL__ Meta::MetaType::MetaType()

    class MetaController{
    private:
        //基础元素变量
        static const usint sizeofINT;
        static const usint sizeofDOUBLE;
        static const usint sizeofCHAR;
        static const usint sizeofLONG;
        static const usint sizeofUNKNOW;

    public:
        //赋值 - 不允许类型发生变化
        int setValue_Int(MetaType& rhs,int value);
        int setValue_DOUBLE(MetaType& rhs,double value);
        int setValue_LONG(MetaType& rhs,long value);
        int setValue_CHAR(MetaType& rhs,const char* strs,usint len);
        int setValue_CHAR(MetaType& rhs,std::string strs);
        int setValue_VARCHAR(MetaType& rhs,const char* strs,usint len);
        int setValue_VARCHAR(MetaType& rhs,std::string strs);
        //求和
        // MetaType getSum(MetaType& rhs1,MetaType& rhs2);//还没实现
        //乘积


        //逻辑

        //比较


    };
};


#endif

