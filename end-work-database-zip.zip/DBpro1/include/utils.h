//utils.h

#ifndef _UTILS_H_
#define _UTILS_H_

#include<vector>
#include<string>
#include<iostream>
#include<boost/regex.hpp>
#include<algorithm>

namespace SavenUtils{
    //清除前后空白
    std::string trim(const std::string string_);

    // 编译时需要额外链接的库 -lboost_regex
    //模式串搜索:大小写不敏感
    std::vector<std::string> RegexSearch(const std::string strs,const std::string regex_str);
    
    
    //模式串匹配:大小写不敏感
    bool RegexMatch(const std::string strs,const std::string regex_str);

    //模式串替换:大小写不敏感
    std::string RegexReplace(const std::string strs,const std::string regex_str,const std::string replace_str);

    std::string RegexDelete(const std::string strs,const std::string regex_str);

    std::string Split_first(const std::string split_string,const std::string mid_string);

    std::string Split_second(const std::string split_string,const std::string mid_string);

    void toupper(char& ch);

    void tolower(char& ch);

    std::string StringtoLower(std::string rhs);

    std::string StringtoUpper(std::string rhs);


    //数字string转int
    int String2Int(const std::string strs);
    
};


#endif // _UTILS_H_

