#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<assert.h>
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<errno.h>
#include<string.h>
#include<sys/sendfile.h>
#include<sys/uio.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>
#include<pthread.h>
#include<sys/time.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<sys/epoll.h>
#include<sys/wait.h>
#include<sys/mman.h>
#include<signal.h>
using namespace std;


class FileController{
private:
    int __file_pointer;//文件描述符
    int pagenum;//现存页面个数
    char name[100];//表名称
    __off_t __offset;//文件指针的当前偏移值
    __off_t __realsize;//文件内容全体大小(包括空洞在内)

public:
    int write(const ubeta8* pointer){
        
    }

};


/*

class FileController;


FileController aimer;
//属性列表
aimer.__file_pointer;//文件描述符
aimer.pagenum;//现存页面个数
aimer.name;//表名称
aimer.__offset;//文件指针的当前偏移值
aimer.__realsize;//文件内容全体(包括空洞在内)
//功能列表
//覆盖写一个页面 页面信息在pointer指向的页面空间中
int aimer.write(const ubeta8* pointer);
//根据pageIndex指定的页面号将数据写入指定的data内存中
int aimer.read(const ubeta8 pageIndex,ubeta8* data);
//检查对应页面号的文件空间是否存在
int aimer.__exist_Page(const ubeta8 pageIndex);
//在文件中向后添加一个新的页面并初始化基本信息
int aimer.__alloc_Back();
//删除文件中的最后一个页面的空间
int aimer.__delet_Back();
//打开表文件
int aimer.open(const char* path);
//关闭文件描述符
void aimer.close();

*/





