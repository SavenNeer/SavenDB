//基本属性的比较

#include<iostream>
#include<cstdio>
#include<fstream>
#include<cstring>
#include<ostream>
#include<string>

using namespace std;

class Test{
public:
    int num;
    char line[20];
    double s;
    Test(){};
    void show(){
        cout << num << " " << line << " " << s << endl;
    }
};


void solve(){
    Test* temp = (Test*)malloc(sizeof(Test));
    ifstream inner("file",ios::binary|ios::in);
    inner.read((char*)temp,sizeof(Test));
    //
    cout << "read here" << endl;
    temp->show();
}

int main(){
    Test* temp = (Test*)malloc(sizeof(Test));
    temp->num = 1234;
    memcpy(temp->line,"sdfsdf",6);
    temp->line[6] = 0;
    temp->s = 3.522;   
    temp->show();
    // cout << "hello" << endl;
    // cout << sizeof(Test) << endl;
    // cout << sizeof(*temp) << endl;
    // cout << "hell" << endl;
    // free(temp);
    //
    ofstream outer("file",ios::binary|ios::out);
    outer.write((char*)temp,sizeof(*temp));
    outer.close();
    //
    free(temp);
    //
    solve();
    return 0;
}

// hexdump -C [filename]


// int main(){
//     __off_t s = 1e17;
//     // cout << s << endl;;
//     printf("%ld\n",s);
//     return 0;
// }

