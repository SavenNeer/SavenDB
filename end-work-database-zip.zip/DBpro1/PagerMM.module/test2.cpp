#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<assert.h>
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<errno.h>
#include<string.h>
#include<sys/sendfile.h>
#include<sys/uio.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>
#include<pthread.h>
#include<sys/time.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<sys/epoll.h>
#include<sys/wait.h>
#include<sys/mman.h>
#include<signal.h>

using namespace std;

typedef long long ll;
typedef unsigned char ubeta8;

char ch[10] = {"s"};
char line[10] = {"pdasd"};


int main(){
    int fd = open("file.tb",O_RDWR);
    __off_t old_file_size = lseek(fd,0,SEEK_END);
    printf("old_file_size = %d\n",(int)old_file_size);
    //
    int res = ftruncate(fd,10);
    printf("res = %d\n",res);
    //
    __off_t new_file_size = lseek(fd,0,SEEK_END);
    printf("new_file_size = %d\n",(int)new_file_size);
    close(fd);
    // int fd = open("file.tb",O_RDWR|O_CREAT,0666);
    // // write(fd,ch,1);
    // //直接设置偏移值
    // int res = lseek(fd,16384*4,SEEK_SET);
    // printf("res1 = %d\n",res);
    // write(fd,ch,1);
    // //获取当前偏移值长度
    // res = lseek(fd,0,SEEK_CUR);
    // printf("res2 = %d\n",res);
    // //向中间写入内容
    // res = lseek(fd,16384,SEEK_SET);
    // write(fd,line,5);
    // // off_t cur_offset = lseek(fd,0,SEEK_CUR);
    // // cout << cur_offset << endl;
    // // printf("cur_offset = %d\n",(int)cur_offset);
    // close(fd);
    return 0;
}



