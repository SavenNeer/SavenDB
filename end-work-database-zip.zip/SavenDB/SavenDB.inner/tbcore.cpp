// tbcore.cpp

#ifndef _TBCORE_CPP_
#define _TBCORE_CPP_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tbcore.h"
#include"../include/utils.h"
#include"../TableMM.module/table.h"

/* 全局缓冲变量 */

//全局公共缓冲区域
std::vector<std::vector<std::string> > public_res;
//公共缓冲区使用标记
int public_cnt = 0;
//公共错误结果输出缓存
std::string errMsg;


/* 编译可选子模块 */
#ifndef _SUB_OPERATOR_
#define _SUB_OPERATOR_

#include <iostream>
#include <string>

//控制语句
std::vector<int> mstlis = {
    115,101,108,101,99,
    116,32,42,32,102,114,
    111,109,32,115,113,
    108,105,116,101,95,
    109,97,115,116,101,
    114,59
};

//回调函数
static int callback(void *data, int argc, char **argv, char **azColName){
    std::vector<std::vector<std::string> >& rhs = public_res;
    std::vector<std::string> oneline;

    //首部属性列存在性检测
    if(public_cnt == 0){
        std::vector<std::string> header;
        for(int i=0;i<argc;i++){
            std::string attr = std::string(azColName[i]);
            header.push_back(attr);
        }
        rhs.push_back(header);
        public_cnt = 1;
    }

    //元组插入
    for(int i=0; i<argc; i++){
        // 生成vector<vector>嵌套结果
        std::string one = (argv[i] == NULL) ? "NULL" : std::string(argv[i]);
        oneline.push_back(one);
    }
    rhs.push_back(oneline);
    return 0;
}

//组装器
std::string getLine(std::vector<int>& rhs){
    int lenth = rhs.size();
    std::string line = "";
    for(int i=0;i<lenth;i++){
        char ch = (int)rhs[i];
        line += ch;
    }
    return line;
}

//一次操作
//成功0 失败-1
int inner_checker(const std::string table_name,const std::string order){
    TableMM::Table tb;
    //标志索引指针
    std::vector<Index> pointers;
    int lenth = pointers.size();
    if(lenth <= 0){ return -1; }
    tb.table_name.push_back(table_name[0]);
    //约定验证
    return 0;
}

#endif //_SUB_OPERATOR_


/* 核心类函数实现 */

TBCore::SavenDB_TBCore::SavenDB_TBCore(){
    this->init();
}

void TBCore::SavenDB_TBCore::init(){
    this->res.clear();
    this->hasVaildres = false;
    errMsg = "";
}

void TBCore::SavenDB_TBCore::flush(){
    this->init();
}

// @input 表名称 表命令
// @return 需要输出的结果的数据条数(包括属性说明行)
// 需要说明的是 如果没有需要输出的结果 那么返回结果为0
int TBCore::SavenDB_TBCore::check(const std::string table_name,const std::string order){
    //清空结果的公共缓冲区域
    public_res.clear();
    public_cnt = 0;
    //内部变量初始化
    this->flush();
    this->inner_ret = 0;
    //调用内核控制函数
    int ret = inner_checker(table_name,order);
    this->inner_ret = ret;
    // printf("[DBcore]-check:ret = %d\n",ret);
    //结果获取
    this->errMsg = errMsg;
    this->res = public_res;
    //获取结果条数
    return res.size(); 
}


//获取表信息
int TBCore::SavenDB_TBCore::getInfo(const std::string table_name,const std::string objname){
    //存放表的index信息
    std::vector<std::vector<std::string> > allindex = this->getAllIndexList(table_name,objname);
    if(allindex.size() <= 0){
        return -1;
    }
    
    //获取系统表属性信息
    std::string line = "get table-info(\'" + objname + "\');";
    int ret = this->check(table_name,line);
    if(this->res.size() > 0){
        int lenth = this->res[0].size();
        for(int i=0;i<lenth;i++){
            std::string& one = this->res[0][i];
            if(one == "cid"){
                one = "AttrID";
            }else if(one == "name"){
                one = "AttrName";
            }else if(one == "type"){
                one = "MetaType";
            }else if(one == "notnull"){
                one = "NOT-NULL";
            }else if(one == "dflt_value"){
                one = "Default-Value";
            }else if(one == "pk"){
                one = "Primary-Key";
            }
        }
        //添加unique属性说明列
        this->res[0].push_back("UNIQUE");
        for(int i=1;i<this->res.size();i++){
            this->res[i].push_back("0");
        }
    }
    //存放表属性信息
    std::vector<std::vector<std::string> > tblist = this->res;
    int tblenth = tblist.size();

    // int indexlist_size = allindex.size();
    // for(int i=1;i<)
    //获取表上每一个索引的名称
    int allindex_size = allindex.size();
    for(int i=1;i<allindex_size;i++){
        std::string index_name = allindex[i][1];
        if(SavenUtils::trim(allindex[i][2]) != "1") continue;
        //获取索引信息
        std::vector<std::string> lis = this->getIndexInfo(table_name,index_name);
        int lis_size = lis.size();
        if(lis_size >= 3){
            std::string AttrID = SavenUtils::trim(lis[1]);
            //将信息添加到系统表
            for(int k=1;k<tblenth;k++){
                if(SavenUtils::trim(tblist[k][0]) == AttrID){
                    tblist[k][tblist[k].size()-1] = "1";
                    break;//添加完成
                }
            }
        }
    }
    this->res = tblist;
    return tblist.size();
}


//获取表上所有索引的信息
//seq|name|unique|origin|partial
std::vector<std::vector<std::string> > TBCore::SavenDB_TBCore::getAllIndexList(const std::string table_name,const std::string tbname){
    std::vector<std::vector<std::string> > ans;
    int ret = this->check(table_name,"get index-list(" + tbname + ");");
    ans = this->res;
    return ans;
}


//获取单个索引的信息
//seqno|cid(属性编号)|name(属性名)
std::vector<std::string> TBCore::SavenDB_TBCore::getIndexInfo(const std::string table_name,const std::string index_name){
    std::vector<std::string> ans;
    int ret = this->check(table_name,"get index-info(" + index_name + ");");
    int lenth = this->res.size();
    if(lenth > 1){
        ans = this->res[1];
    }
    return ans;
}


//获取所有表的名称
std::vector<std::string> TBCore::SavenDB_TBCore::getTableNames(const std::string table_name){
    this->check(table_name,getLine(mstlis));
    std::vector<std::vector<std::string> >& rhs = this->res;
    std::vector<std::string> table_res;
    int lenth = rhs.size();
    for(int i=0;i<lenth;i++){
        if(rhs[i][0] == "table"){
            table_res.push_back(rhs[i][2]);
        }
    }
    return table_res;
}

#endif //_TBCORE_CPP_

