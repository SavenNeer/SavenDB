// tbcore.h
#pragma once
#ifndef _TBCORE_H_
#define _TBCORE_H_


#include <string>
#include <vector>


namespace TBCore{

    class SavenDB_TBCore{
    public:
        //结果内容
        std::vector<std::vector<std::string> > res;
        //结果是否指向了有效的内容
        bool hasVaildres;
        //错误信息
        std::string errMsg;
        //结果正确性标记
        int inner_ret;
    public:
        //构造函数
        SavenDB_TBCore();
        //成员初始化 功能相同
        void init();
        void flush();
    public:
        //表内语句执行 启动前自动调用flush()
        int check(const std::string table_name,const std::string order);
        //获取表信息-之后从res成员变量中取出即可
        int getInfo(const std::string table_name,const std::string objname);
        //获取所有表的名称
        std::vector<std::string> getTableNames(const std::string table_name);
        //获取单个索引的信息
        std::vector<std::string> getIndexInfo(const std::string table_name,const std::string index_name);
        //获取表上所有索引的信息
        std::vector<std::vector<std::string> > getAllIndexList(const std::string table_name,const std::string tbname);
    };
};


#endif //_TBCORE_H_

