cd /home/ubuntu/DBpro4/SavenDB/SavenDB.inner/design/ && cat t1.design > ../tbcore.cpp
