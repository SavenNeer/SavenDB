cd /home/ubuntu/DBpro4/SavenDB/SavenDB.inner/design/ && cat t0.design > ../tbcore.cpp
