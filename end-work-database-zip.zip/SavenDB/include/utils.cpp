// utils.cpp

#ifndef _UTILS_CPP_
#define _UTILS_CPP_

#include"utils.h"


//清除前后空白
std::string SavenUtils::trim(const std::string string_)
{
    std::string s = string_;
    if (s.empty())return "";
    int f = s.find_first_not_of(" \t");
    return s.substr(f,s.find_last_not_of(" \t") - f + 1);
}

// 编译时需要额外链接的库 -lboost_regex
//模式串搜索:大小写不敏感
std::vector<std::string> SavenUtils::RegexSearch(const std::string strs,const std::string regex_str){
    std::string str = strs;
    boost::regex expression(regex_str,boost::regex::icase);
    boost::smatch what;
    std::vector<std::string> res;//搜索结果
    //
    std::string::const_iterator start = str.begin();
    std::string::const_iterator end = str.end();
    //
    while(boost::regex_search(start, end, what, expression)){
        // std::cout << what[0] << std::endl;
        res.push_back(SavenUtils::trim(what[0]));
        start = what[0].second;
    }
    return res;
}


//模式串匹配:大小写不敏感
bool SavenUtils::RegexMatch(const std::string strs,const std::string regex_str){
    std::string str = strs;
    boost::regex expression(regex_str,boost::regex::icase);
    boost::smatch what;
    std::vector<std::string> res;//搜索结果
    std::string::const_iterator start = str.begin();
    std::string::const_iterator end = str.end();
    if(boost::regex_search(start, end, what, expression)){
        return true;
    }
    return false;
    // //模式串:大小写不敏感
    // boost::regex reg(regex_str,boost::regex::icase);
    // //模式匹配
    // return boost::regex_match(strs,reg);
}

//模式串替换:大小写不敏感
std::string SavenUtils::RegexReplace(const std::string strs,const std::string regex_str,const std::string replace_str){
    //模式串:大小写不敏感
    boost::regex reg(regex_str,boost::regex::icase);
    //模式替换
    std::string ans = boost::regex_replace(strs,reg,replace_str);
    return SavenUtils::trim(ans);
}

std::string SavenUtils::RegexDelete(const std::string strs,const std::string regex_str){
    //模式串:大小写不敏感
    boost::regex reg(regex_str,boost::regex::icase);
    //模式替换
    std::string ans = boost::regex_replace(strs,reg,"");
    return SavenUtils::trim(ans);
}

std::string SavenUtils::Split_first(const std::string split_string,const std::string mid_string)
{
    size_t pos = split_string.find(mid_string);
    if(pos == split_string.npos)return "";
    std::string str1 = split_string.substr(0,pos);
    return str1;
}

std::string SavenUtils::Split_second(const std::string split_string,const std::string mid_string)
{
    size_t pos = split_string.find(mid_string);
    if(pos == split_string.npos)return "";
    size_t i = pos+mid_string.size();
    std::string str2 = split_string.substr(i,split_string.size()-i);
    return str2;
}

void SavenUtils::toupper(char& ch){
    if(ch >= 'a' && ch <= 'z'){
        ch = ch - 'a' + 'A';
    }
}

void SavenUtils::tolower(char& ch){
    if(ch >= 'A' && ch <= 'Z'){
        ch = ch - 'A' + 'a'; 
    }
}

std::string SavenUtils::StringtoLower(std::string rhs){
    transform(rhs.begin(),rhs.end(),rhs.begin(),::tolower);
    return rhs;
}

std::string SavenUtils::StringtoUpper(std::string rhs){
    transform(rhs.begin(),rhs.end(),rhs.begin(),::toupper);
    return rhs;
}

std::string SavenUtils::StringReplace(const std::string rhs,const std::string aim,const std::string rp){
    std::string line = "";
    if(rhs.find(aim) == rhs.npos) return rhs;
    line = SavenUtils::Split_first(rhs,aim) + rp + SavenUtils::Split_second(rhs,aim);
    return line;
}


//数字string转int
int SavenUtils::String2Int(const std::string strs){
    int lenth = strs.size();
    int num = 0,beginer = 0,flag = 1;
    if(strs[beginer] == '-'){
        flag = -1;
        beginer++;
    }
    while(beginer < lenth){
        if(isdigit(strs[beginer])){
            num = num * 10 + strs[beginer] - '0';
        }else{
            break;
        }
        beginer++;
    }
    return flag * num;
}

//指定字符串中的单个左括号 找到对应的右括号 需要保证语句中的括号是匹配的
//找不到-1 找到下标 如果不检查语句中的括号的匹配
int SavenUtils::pickBrackets(const std::string line,int left_index){
    int lenth = line.size();
    if(left_index >= lenth || line[left_index] != '('){
        return -1;
    }
    //
    int flag = 0;
    for(int i=left_index;i<lenth;i++){
        if(line[i] == '('){
            flag++;
        }else if(line[i] == ')'){
            flag--;
        }
        //检查合法性
        if(flag < 0){
            return -1;
        }else if(flag == 0 && i > left_index){
            return i;
        }
    }
    return -1;
}


#endif // _UTILS_CPP_

