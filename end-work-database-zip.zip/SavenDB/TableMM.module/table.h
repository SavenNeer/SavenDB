// table.h

#ifndef _TABLE_H_
#define _TABLE_H_

#include"../include/TypeStat.h"
#include"../index.module/Bptree.h"
#include"../MetaST.module/MetaType.h"
#include"PagePool.h"
#include<vector>
#include<string>

/*
表的生成、释放与管理过程:

[1]数据库启动后，
表字典从字典文件中加载所有表的信息
但表字典不加载具体的表内容

[2]一旦基本表要求生成表实体，
表字典应该先查找是否存在已经建立的实体
如果存在则返回已经建立的表实体指针

[3]基本表一旦使用完毕，
应当立即释放Table对象，
但页面池中对应的页面无需变化

[4]新生成的表实体应当向表字典注册
释放的表实体也应当向表字典注销

[5]所有的表实体都应存储在表字典中
数据库内核寻找实体表应当通过表字典

[6]允许内核在申请到表实体后直接操作表实体
但是这些操作必须经过权限管理系统鉴定
表实体本身不负责这种权限的鉴定

*/

/* 前向声明区域 */
namespace DBInfo{
    class Attribute;
    class TableInfo;
    class DBTables;
}



/* 表类声明 */


/*
Table变量的使用方法

元数据:class MetaType;
元组:class Tuple;

建立:
Table tb("table_name",false,&pos);

获取元组个数
长度 = tb.legth();

直接查找:
tb[0]:第0个元组
tb[0]["name"]:第0个元组的name属性值

修改:
修改元组 实现上需要删除元组后插入新的元组
tb[0] = Tuple示例;
修改属性值 tb[0]["name"] = MetaType示例;
(这里的修改是复制拷贝型的修改
这里修改的实现比较特殊 是Tuple对象tb[0]根据获取的"name"标识
重新在缓冲区中构造新的元组对象 然后将修改好的对象同步到页面中)

插入:
元组插入 tb.insert(Tuple);

删除:
元组删除1 tb.delete(Index<p-g>);
元组删除2 tb.delete(tb[0]);
元组删除3 tb.delete(0);

同步(虚拟表调用无效):
直接同步 tb.TableSync();
周期同步 tb.RoundSync();

*/

namespace TableMM{

    class Table{
    public:
        //表明该对象是否有效
        bool isVaild = false;
        //表名称
        std::string table_name;
        //是否为虚表
        bool isVirtual = false;
        //表信息指针需要向数据字典查询
        DBInfo::TableInfo* tbinfo = nullptr;
        //索引指针
        std::map<std::string,Bpt::BPTree*> tbIndexMap;
        //依赖的视图元素-即时生成
        std::map<std::string,std::string> view_list;
        //页面池指针
        PagesMM::PagePool* pagepool_pointer = nullptr;
    public:
        //元组视角-按行存储<p-g>索引
        std::vector<Index> tb_tuples;
    public://初始化-只允许显式初始化
        explicit Table();//不建议使用该函数
        /* 初始化说明
         * SavenDB内核向全局表字典发起建立实体表的请求
         * 表字典先进行权限检查 当检查通过后
         * 表字典搜索发现不存在已有的表实体
         * 表字典将加载好的TableInfo指针传递给构造函数
         * 构造函数建立并加载完成后 向表字典注册登录表实体
         * 最后全局表字典返回表实体的指针供内核继续更多的操作
         * 
         * 如果isVirtual=ture 则tbinfo一定为nullptr
         * 如果isVirtual=false 则tbinfo一定不能为nullptr
        */
        explicit Table(const std::string table_name,bool isVirtual=false,DBInfo::TableInfo* tbinfo=nullptr);
    public:
        //获取元组总个数-表的逻辑大小
        int length()const;
    public:
        //插入功能
        //成功0 失败-1
        int insert(Meta::Tuple rhs);
        //删除功能
        //成功0 失败-1
        int remove(Meta::Tuple rhs);
        int remove(Index index);
        //查找
        //存在1 不存在0
        int tupleFind(Meta::Tuple rhs);
        int tupleFind(Index index);
    public:
        //同步建议请求
        void TableSync();
        void RoundSync();
    };

};



#endif // _TABLE_H_


