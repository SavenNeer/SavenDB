// table.cpp

#ifndef _TABLE_CPP_
#define _TABLE_CPP_


/* 前向声明对应的头文件引用 */

#include"../DBMM.module/DBInfo.h"
#include"table.h"


/* 实现主体部分 */

TableMM::Table::Table(){
    this->table_name = "";
    this->isVirtual = false;
    this->tbinfo = nullptr;
    this->tb_tuples.clear();
    this->isVaild = false;
}

//带参初始化
TableMM::Table::Table(const std::string table_name,bool isVirtual,DBInfo::TableInfo* tbinfo){
    if(isVirtual == true && tbinfo != nullptr){
        this->isVaild = true;
        return;
    }
    if(isVirtual = false && tbinfo == nullptr){
        this->isVaild = true;
        return;
    }
    //初始化回头再写
}

//获取元组总个数-表的逻辑大小
int TableMM::Table::length()const{
    return this->tb_tuples.size();
}

//插入功能
//成功0 失败-1
int TableMM::Table::insert(Meta::Tuple rhs){
    int lenth = rhs.tuplis.size();
    ubeta8 buf[lenth*280];
    int temp = 0;
    for(int i=0;i<lenth;i++){
        memcpy(buf,rhs.tuplis[i].mm_pointer,rhs.tuplis[i].data_size);
        temp += rhs.tuplis[i].data_size;
    }
    return this->pagepool_pointer->WriteIn(buf,temp,rhs.pgIndex.page_index,rhs.pgIndex.group_index);
}

//删除功能
//成功0 失败-1
int TableMM::Table::remove(Meta::Tuple rhs){
    if(!this->tupleFind(rhs)){
        return -1;
    }
    //删除操作
    this->pagepool_pointer->delete_data(rhs.pgIndex.page_index,rhs.pgIndex.group_index);
    return 0;
}

//删除功能
//成功0 失败-1
int TableMM::Table::remove(Index index){
    //删除操作
    this->pagepool_pointer->delete_data(index.page_index,index.group_index);
    return 0;
}


#endif // _TABLE_CPP_

