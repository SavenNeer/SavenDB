cd /home/ubuntu/DBpro4/SavenDB/

cd ./main.module/
rm *.o
cd /home/ubuntu/DBpro4/SavenDB/

# cmd.cpp
cd cmd.module/ && g++ -c cmd.cpp && mv cmd.o ../main.module/
cd /home/ubuntu/DBpro4/SavenDB/

# utils.cpp
cd include/ && g++ -c utils.cpp && mv utils.o ../main.module/
cd /home/ubuntu/DBpro4/SavenDB/

# sql_grant.cpp
cd right.module/ && g++ -c sql_grant.cpp && mv sql_grant.o ../main.module/
cd /home/ubuntu/DBpro4/SavenDB/

# dbuser.cpp
cd user.module/ && g++ -c dbuser.cpp && mv dbuser.o ../main.module/
cd /home/ubuntu/DBpro4/SavenDB/

# sql_view.cpp
cd view.module/ && g++ -c sql_view.cpp && mv sql_view.o ../main.module/
cd /home/ubuntu/DBpro4/SavenDB/

# sql_index.cpp
cd index.module/ && g++ -c sql_index.cpp && mv sql_index.o ../main.module/
cd /home/ubuntu/DBpro4/SavenDB/

# 
cd checker.module/ && ./cmake.sh
cd /home/ubuntu/DBpro4/SavenDB/
cd checker.module/ && ./make.sh
