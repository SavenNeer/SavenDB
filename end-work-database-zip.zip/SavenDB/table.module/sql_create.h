// sql_create.h

#ifndef _SQL_CREATE_H_
#define _SQL_CREATE_H_

#include<string>
#include<map>
#include<algorithm>
#include"../DBMM.module/DBInfo.h"
#include"../include/utils.h"

namespace SQL_Create{

    /* create table parser 
     * @input std::string create_table的sql语句
     * @return 单个TableInfo对象
    */

    //规整主码同步性
    void confirm_PrimaryKeys(DBInfo::TableInfo& result_tb);

    //解析主码
    //成功:0
    //失败:-1
    int parse_PrimaryKeys(std::string line,DBInfo::TableInfo& result_tb);

    //解析并设置外码信息
    //成功:0
    //失败:-1
    int parse_ForeignKeys(std::string line,DBInfo::TableInfo& result_tb);

    //解析并获取特别声明属性
    // input:单个属性的描述行及其Attribute变量的引用 保证line小写
    int parse_DataAttrs(std::string line,DBInfo::Attribute& result_attr);

    //解析并获取属性类型
    // 成功 0/1 1表示设置的数据类型可能存在数据限制
    // 失败 -1 未发现数据类型的声明语句
    int parse_DataType(std::string line,DBInfo::Attribute& result_attr);

    //获取限制大小
    // 成功:0获取限制 1未检测到限制
    // 失败:-1 多个定义字段错误
    // 失败:-2 定义字段内限制的解析错误
    int get_LimitInt(std::string line,DBInfo::Attribute& result_attr);

    //解析所有属性值
    //成功:0
    //失败:-1
    int parse_Attributes(std::vector<std::string>& rhs,DBInfo::TableInfo& result_tb);


    /* !!!!! */
    // 通过解析一个crete table语句获取表的信息
    // 成功:0 表信息位于result_tb中
    // 失败:-1 create语句不合法 不支持多行解析
    int create_table(const std::string order,DBInfo::TableInfo& result_tb);

};



#endif // _SQL_CREATE_H_

