cd /home/ubuntu/DBpro4/SavenDB/MetaST.module/ && g++ -c MetaType.cpp && mv MetaType.o ../test

cd /home/ubuntu/DBpro4/SavenDB/TableMM.module/ && g++ -c table.cpp && mv table.o ../test

cd /home/ubuntu/DBpro4/SavenDB/DBMM.module/ && g++ -c DBInfo.cpp && mv DBInfo.o ../test

cd /home/ubuntu/DBpro4/SavenDB/table.module/ && g++ -c sql_create.cpp && mv sql_create.o ../test

cd /home/ubuntu/DBpro4/SavenDB/include/ && g++ -c utils.cpp && mv utils.o ../test

cd /home/ubuntu/DBpro4/SavenDB/test/ && g++ MetaType.o \
test1.cpp table.o DBInfo.o sql_create.o utils.o -o test \
/usr/lib/x86_64-linux-gnu/libboost_regex.so.1.65.1

