#include <iostream>
#include <algorithm>
#include <string>
#include <cstring>
#include <vector>
#include <stack>
#include <set>
#include <queue>
#include <map>
#include <cstdio>
#include <list>
#include <cmath>
#include "../include/utils.h"
#include "../table.module/sql_create.h"
#include "../DBMM.module/DBInfo.h"
#define debug_mode false
#define mem(s, value) memset(s, value, sizeof(s))
#define IOS ios::sync_with_stdio(false)
#define INTXT frein("in.txt");
#define frein(s) freopen(s, "r", stdin)
#define DEBUG if (debug_mode)
#define esp 1e-8
//#pragma comment(linker, "/STACK:1024000000,1024000000")
typedef long long ll;
typedef unsigned long long ull;
using namespace std;
const double PI = acos(-1.0);
const int maxn = 2e5 + 10;
string line = "CREATE TABLE S(SNO CHAR(2) PRIMARY KEY, SNAME VARCHAR(20) NOT NULL, STATUS INT,CITY VARCHAR(20),primary key(SNO,SNAME),foreign key(CITY) references PPS(CITY));";

int main(){
    // line = SavenUtils::StringtoLower(line);
    cout << line << endl;
    DBInfo::TableInfo res;
    SQL_Create::create_table(line,res);
    res.show();
    return 0;
}


