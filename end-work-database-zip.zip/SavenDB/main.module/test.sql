CREATE TABLE S(SNO CHAR(2) PRIMARY KEY, SNAME VARCHAR(20) NOT NULL UNIQUE, STATUS INT check(STATUS<=20),CITY VARCHAR(20));

insert into S(SNO,SNAME,STATUS,CITY) VALUES ("S1","jingyi",20,"tianjin");
insert into S(SNO,SNAME,STATUS,CITY) VALUES ("S1","jingyi",20,"tianjin");
insert into S(SNO,SNAME,STATUS,CITY) VALUES ("S2","shengxi",10,"beijing");
insert into S(SNO,SNAME,STATUS,CITY) VALUES ("S3","dongfang",30,"beijing");
insert into S(SNO,SNAME,STATUS,CITY) VALUES ("S4","pqoe",12,"tianjin");
insert into S(SNO,SNAME,STATUS,CITY) VALUES ("S5","ddsf",17,"hezeshi");
insert into S values ("S7","sdf",16,"sfsd");

select * from S;

create view vt as select SNO,SNAME from S where STATUS<16;
create view vt2 as select TYPEC from S;


--- 


create table Course(Cno int primary key,Cname char(20) UNIQUE,Cpoint int not null);

insert into Course values(1,"database",3);
insert into Course values(2,"datastruct",3);
insert into Course values(3,"ossys",3);
insert into Course values(4,"image",NULL);
insert into Course values(4,"image",4);
insert into Course values(5,"ossys",6);

-- 多条件
select * from Course where Cno between 2 and 4 and Cname="datastruct";
-- 双层嵌套
select Cname from Course where Cpoint<4 and Cno in (select Cno from Course where Cno>=3);

create view vi as select Cname from Course where Cpoint=3;


create table Student(Sno int primary key,Sname varchar(10),age int check(age<=30));

insert into Student values(1,"cyym",18);
insert into Student(Sno) values (1);
insert into Student values(2,"dkf",17);
insert into Student values(3,"sdf",14);
insert into Student values(4,"rid",38);
insert into Student values(4,"rid",28);



create table SC(
Cno int,
Sno int,
Grade int check(Grade between 0 and 100),
primary key(Cno,Sno),
foreign key(Cno) references Course(Cno),
foreign key(Sno) references Student(Sno)
);

select Sno,avg(Grade) from SC group by Sno;
insert into Course values(8,"sdfD",3);
insert into SC values (1,2,33);
insert into SC values (1,8,34);
insert into SC values (2,2,99);


delete from SC where SNO=8;


---
create index index1 on SC(Grade asc);


