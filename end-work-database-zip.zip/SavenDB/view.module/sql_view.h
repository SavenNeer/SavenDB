//sql_view.h


#ifndef _SQL_VIEW_H_
#define _SQL_VIEW_H_

#include<map>
#include<string>
#include<stdio.h>
#include<vector>
#include"../SavenDB.inner/tbcore.h"

namespace Viewer{

    //视图信息协调器
    class ViewKeeper{
    public:
        const std::string view_path = "../data/view.kp";
        //视图信息是否存在
        std::map<std::string,int> view_vis;
        //视图名对应的视图定义语句
        std::map<std::string,std::string> allview;
    public:
        ViewKeeper();
        //查看视图是否存在
        //成功1 失败0
        int hasView(const std::string viewname);
        //添加视图信息
        //成功0 失败-1
        int addView(const std::string viewname,const std::string line);
        //删除视图信息
        int delView(const std::string viewname);
        //读取文件数据
        int __readData();
        //向文件写入数据
        int __writeData();
    public:
        //获取所有存在的视图
        std::vector<std::string> getAllViewInfo();
        // //测试所有视图的有效性并删除无效的视图
        // //返回被删除的视图的名称与创建sql语句
        // std::vector<std::vector<std::string> > delInvaildView(TBCore::SavenDB_TBCore& rhs);
    };

};



#endif //_SQL_VIEW_H_
