//sql_index.h

#ifndef _SQL_INDEX_H_
#define _SQL_INDEX_H_

#include"Bptree.h"
#include"../PagerMM.module/PageManager.h"
#include<map>
#include<vector>
#include<string>

namespace DBIndex{

    //create index index_name on table 

    //索引保存器
    class CommonIndex{
    public:
        //基本索引信息
        std::string index_name;
        std::string table_name;
        std::string define_sql;
        //详细指针
        Bpt::BPTree* bplustree;
    public:
        CommonIndex();
        CommonIndex(const std::string index_name,const std::string table_name,const std::string define_sql);
    };

    //索引协调器
    class IndexKeeper{
    public:
        //存在性标志
        std::map<std::string,int> index_vis;
        //内容保存
        std::map<std::string,CommonIndex> allIndex;
    public:
        IndexKeeper();
        void flush();
    public:
        //添加索引
        //成功0 失败-1
        int addIndex(const std::string tablename,const std::string indexname,const std::string _sql);
        //删除索引
        //成功0 失败-1
        int delIndex(const std::string indexname);
        //查找索引存在性
        //成功1 失败0
        int hasIndex(const std::string indexname);

        //获取索引表的索引信息
        //vector< vector<string(索引名),string(表名),string(sql语句) >
        std::vector<std::vector<std::string> > getIndexOnTable(const std::string tbname);
        //删除某个表涉及的所有索引
        int deleteIndexOnTable(const std::string tbname);

        //获取所有记录中的索引
        //vector< vector<string(索引名),string(表名),string(sql语句)> >
        std::vector<std::vector<std::string> > getAllIndex();
    };

    //读写函数
    int IndexKeeperReader(IndexKeeper& rhs);
    int IndexKeeperWriter(IndexKeeper& rhs);

};



#endif //_SQL_INDEX_H_
