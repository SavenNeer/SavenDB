// #include"dbuser.h"
// #include<iostream>

// using namespace std;

// signed main(){
//     DBUser::UserChecker ck;
//     ck.show();
//     //测试权限
//     int ret = ck.admit("root","tablename","insert");
//     cout << "ret = " << ret << endl;
//     return 0;
// }

