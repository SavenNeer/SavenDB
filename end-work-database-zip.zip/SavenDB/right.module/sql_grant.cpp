// sql_grant.cpp

//用于解析grant语句

#ifndef _SQL_GRANT_CPP_
#define _SQL_GRANT_CPP_


/*
不支持public与all privileges
*/

#include"sql_grant.h"
#include"../include/utils.h"
#include<sstream>

void Rights::RightChecker::init(){
    this->rilis.clear();
    this->tblis.clear();
    this->usrlis.clear();
}

void Rights::RightChecker::setUser(const std::string username){
    this->cur_username = username;
}

void show_vector_string(std::vector<std::string>& rhs){
    int lenth = rhs.size();
    printf("show vetor<string>:");
    for(int i=0;i<lenth;i++){
        printf(" [%s]",rhs[i].c_str());
    }
    printf("\n");
}

//解析grant语句 有效返回1 无效返回-1
int Rights::RightChecker::parse_grant(const std::string line,DBUser::UserChecker& sysck){
    this->init();
    /* 语法解析 */

    //截取分号前的标志
    std::string order = SavenUtils::Split_first(line,";");
    //获取权限名称
    this->rilis = SavenUtils::RegexSearch(order,"(insert|delete|create|drop|update|select)");
    //用户信息段
    std::string bk = SavenUtils::trim(SavenUtils::Split_second(order,"on"));
    std::string userseg = SavenUtils::trim(SavenUtils::Split_second(bk," to ")) + ",";
    //获取用户名
    while(1){
        std::string part = SavenUtils::Split_first(userseg,",");
        if(part == "") break;
        this->usrlis.push_back(part);
        userseg = SavenUtils::Split_second(userseg,",");
        if(userseg == "") break;
    }
    //获取表名
    std::string nameseg = SavenUtils::Split_first(bk,"to");
    nameseg = SavenUtils::trim(nameseg) + ",";
    //兼容类型声明
    std::stringstream ss(nameseg);
    std::string one = "";
    if(ss >> one){
        one = SavenUtils::trim(one);
        if(one == "table"){
            nameseg = SavenUtils::trim(SavenUtils::Split_second(nameseg,"table"));
        }else if(one == "view"){
            nameseg = SavenUtils::trim(SavenUtils::Split_second(nameseg,"view"));
        }
    }
    //
    while(1){
        std::string part = SavenUtils::trim(SavenUtils::Split_first(nameseg,","));
        if(part == "") break;
        this->tblis.push_back(part);
        nameseg = SavenUtils::trim(SavenUtils::Split_second(nameseg,","));
        if(nameseg == "") break;
    }

    /* 语法解析结果 */
    printf("rights:");
    show_vector_string(this->rilis);
    printf("tables:");
    show_vector_string(this->tblis);
    printf("users:");
    show_vector_string(this->usrlis);

    int rilen = this->rilis.size();
    int tblen = this->tblis.size();
    int usrlen = this->usrlis.size();
    if(rilen == 0 || tblen == 0 || usrlen == 0){
        printf("[error]-grant wrong struct\n");
        return -1;
    }

    /* 授权操作 */
    //开始授权
    for(int i=0;i<usrlen;i++){//遍历用户
        for(int k=0;k<tblen;k++){//遍历涉及的授权表
            int ret = sysck.grantRights(this->cur_username,this->usrlis[i],this->tblis[k],this->rilis);
            if(ret < 0){
                printf("[error]-grant part error\n");
                return -1;
            }
        }
    }
    return 1;
}

//解析revoke语句 有效返回1 无效返回-1
int Rights::RightChecker::parse_revoke(const std::string line,DBUser::UserChecker& sysck){
    this->init();
    /* 语法解析 */
    //revoke update,select on tbname from U1,U2
    //截取分号前的标志
    std::string order = SavenUtils::Split_first(line,";");
    //获取权限名称
    this->rilis = SavenUtils::RegexSearch(order,"(insert|delete|create|drop|update|select)");
    //用户信息段
    std::string bk = SavenUtils::trim(SavenUtils::Split_second(order,"on"));
    std::string userseg = SavenUtils::trim(SavenUtils::Split_second(bk,"from")) + ",";
    //获取用户名
    while(1){
        std::string part = SavenUtils::Split_first(userseg,",");
        if(part == "") break;
        this->usrlis.push_back(part);
        userseg = SavenUtils::Split_second(userseg,",");
        if(userseg == "") break;
    }
    //获取表名
    std::string nameseg = SavenUtils::Split_first(bk,"from");
    nameseg = SavenUtils::trim(nameseg) + ",";
    while(1){
        std::string part = SavenUtils::trim(SavenUtils::Split_first(nameseg,","));
        if(part == "") break;
        this->tblis.push_back(part);
        nameseg = SavenUtils::trim(SavenUtils::Split_second(nameseg,","));
        if(nameseg == "") break;
    }


    /* 语法解析结果 */
    printf("rights:");
    show_vector_string(this->rilis);
    printf("tables:");
    show_vector_string(this->tblis);
    printf("users:");
    show_vector_string(this->usrlis);

    int rilen = this->rilis.size();
    int tblen = this->tblis.size();
    int usrlen = this->usrlis.size();
    if(rilen == 0 || tblen == 0 || usrlen == 0){
        printf("[error]-revoke wrong struct\n");
        return -1;
    }

    /* 收权操作 */
    //开始收权
    for(int i=0;i<usrlen;i++){//遍历用户
        for(int k=0;k<tblen;k++){//遍历涉及的授权表
            int ret = sysck.revokeRights(this->cur_username,this->usrlis[i],this->tblis[k],this->rilis);
            if(ret < 0){
                printf("[error]-grant part error\n");
                return -1;
            }
        }
    }
    return 1;
}






#endif //_SQL_GRANT_CPP_
