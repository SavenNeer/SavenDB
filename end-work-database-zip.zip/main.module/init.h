//只有main.cpp文件允许include该头文件


#include<stdio.h>
#include<iostream>


//系统帮助信息
void showSysInfo(){
    printf("Welcome SavenDB DBMS!\n");
    printf("Created by SavenNeer for SDUST IOT DB-class-design\n");
}


void showSysHelp(){
    //
}


