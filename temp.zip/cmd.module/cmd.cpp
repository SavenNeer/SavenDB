//cmd.cpp

#ifndef _CMD_CPP_
#define _CMD_CPP_

#include"../include/utils.h"
#include"cmd.h"
#include<iostream>



//根据结束标志获取多行语句并组成一句
std::string CMD::dbget(const char flag){
    std::string all = "";
    while(1){
        std::string line = "";
        std::getline(std::cin,line);
        line = " " + SavenUtils::trim(line) + " ";
        int lenth = line.size();
        int ok = 0;
        for(int i=0;i<lenth;i++){
            all += line[i];
            if(line[i] == flag){
                ok = 1;
                break;
            }
        }
        if(ok)break;
    }
    return all;
}


//字符串存在性查找
inline int stringExists(const std::string line,const std::string aim){
    return line.find(aim) == line.npos ? 1 : 0;
}


//特殊函数声明
int not_cmd_check(const std::string order);

//语句粗分类
CMD::orderType CMD::OrderChecker::check(const std::string _cmd){
    if(stringExists(_cmd,".help")){
        return CMD::orderType::SYS_HELP;
    }else if(stringExists(_cmd,".quit")){
        return CMD::orderType::SYS_QUIT;
    }else if(_cmd == "clear"){
        return CMD::orderType::SYS_CLEAR;
    }
    //特殊检查
    if(not_cmd_check(_cmd)){
        return CMD::orderType::NOT_SQL;
    }
    //可运行的sql语句
    return CMD::orderType::RUN_SQL;
}

//sql粗分类
CMD::orderType CMD::OrderChecker::sql_check(const std::string _cmd){
    if(stringExists(_cmd,"grant")){
        return CMD::orderType::SQL_GRANT;
    }else if(stringExists(_cmd,"revoke")){
        return CMD::orderType::SQL_REVOKE;
    }else if(stringExists(_cmd,"create")){
        return CMD::orderType::SQL_CREATE;
    }else if(stringExists(_cmd,"drop")){
        return CMD::orderType::SQL_DROP;
    }
    return CMD::orderType::SQL_NORMAL;
}

/* int not_cmd_check(const std::string order); */
/* 需要在这里实现对特殊命令的封禁 */

int not_cmd_check(const std::string order){
    return 1;
}

#endif //_CMD_CPP_
