g++ -c dbuser.cpp
g++ dbuser.o test1.cpp -o test1
