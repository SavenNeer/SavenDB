// TypeStat.h

#ifndef _TYPESTAT_H_
#define _TYPESTAT_H_

#include<utility>
#include<deque>
#include<vector>
#include<string>
#include<stdio.h>

// 内置类型声明

typedef char sint;

typedef unsigned char ubeta8;

typedef unsigned short ubeta16;


//链式组编号集合
// typedef std::vector<ubeta8> GrpList;

#define GrpList std::deque<ubeta8>

//<p-g>索引:<Page,Group>
struct Index{
    ubeta8 page_index;
    ubeta8 group_index;
};





typedef std::vector<std::pair<std::string,std::pair<std::string,std::string> > > ReferenceList;


// //内存管理涉及到的类型

// //页面号
// typedef unsigned int uint32;

// //组号
// typedef unsigned char uint8;

// //<页面-组>位置对
// typedef struct { uint32 pageIndex; uint8 groupIndex; } stpos;



#endif

