

/* C++标准库区 */
#include<stdio.h>
#include<iostream>
#include<string>


/* 系统头文件引用区 */
#include"init.h"
#include"../user.module/dbuser.h"
#include"../cmd.module/cmd.h"
#include"../right.module/sql_grant.h"

using namespace std;

/* 全局控制变量 */

//系统用户权限管理器-自动初始化并读取文件
DBUser::UserChecker sys_UserChecker;

//系统命令分类器
CMD::OrderChecker sys_OrderChecker;

//全局grant/revoke权限解析器
Rights::RightChecker sys_RightChecker;

//当前全局用户名称
string cur_user = "";


/* 主函数 */

signed main(){
    //系统提示信息
    showSysInfo();
    //help用法说明
    showSysHelp();

    //通知grant/revoke权限解析器当前的用户名称
    sys_RightChecker.setUser(cur_user);
    
    string line = "";
    while(1){
        string cli_flag = cur_user + "@SavenDB >"; 
        cout << cli_flag;
        //接收语句并分类
        line = CMD::dbget(';');
        CMD::orderType ty = sys_OrderChecker.check(line);
        if(ty == CMD::orderType::SYS_QUIT){
            break;
        }else if(ty == CMD::orderType::SYS_CLEAR){
            system("clear");
            continue;
        }else if(ty == CMD::SQL_GRANT){
            printf("[CMD::SQL_GRANT]\n");
            sys_RightChecker.parse_grant(line,sys_UserChecker);
        }else if(ty == CMD::SQL_REVOKE){
            printf("[CMD::SQL_REVOKE]\n");
            sys_RightChecker.parse_revoke(line,sys_UserChecker);
        }else{
            printf("input-else\n");
        }
        printf("---ok---\n");
    }

    /* 程序收尾工作 */


    printf("Over\n");
    return 0;
}





