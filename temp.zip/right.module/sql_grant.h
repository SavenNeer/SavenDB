// sql_grant.h

//用于解析grant/revoke语句

#ifndef _SQL_GRANT_H_
#define _SQL_GRANT_H_

#include<string>
#include<vector>
#include"../user.module/dbuser.h"

namespace Rights{

    class RightChecker{
    public:
        //当前系统的用户名
        std::string cur_username;
        //权限种类
        std::vector<std::string> rilis;
        //表列表
        std::vector<std::string> tblis;
        //用户对象列表
        std::vector<std::string> usrlis;
        //操作对象的类型
        std::string aim;
    public:
        //解析grant语句 有效返回1 无效返回-1
        int parse_grant(const std::string line,DBUser::UserChecker& sysck);
        //解析revoke语句 有效返回1 无效返回-1
        int parse_revoke(const std::string line,DBUser::UserChecker& sysck);
    public:
        //初始化
        void init();
        //设置当前系统的用户名称
        void setUser(const std::string username);
    };

};



#endif //_SQL_GRANT_H_
